const express = require("express");
const cors = require("cors");

const app = express();

app.use(cors());
app.use(express.json());

// ROUTES
const evRoutes = require("./routes/ev");
const stationRoutes = require("./routes/stations");
const bookingRoutes = require("./routes/bookings");

app.use("/api/ev", evRoutes);
app.use("/api/stations", stationRoutes);
app.use("/api/bookings", bookingRoutes);

// Root check
app.get("/", (req, res) => {
  res.send("COOKEYS Backend is running 🚀");
});

// Start server
app.listen(5000, () => {
  console.log("Backend running on http://localhost:5000");
});
