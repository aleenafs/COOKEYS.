const express = require("express");
const router = express.Router();
const evModels = require("../db/evModels.json");

router.get("/", (req, res) => {
  res.json(evModels);
});

module.exports = router;
