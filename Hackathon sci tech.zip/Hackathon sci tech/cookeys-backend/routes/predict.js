const express = require("express");
const router = express.Router();
const stations = require("../db/stations.json");

router.get("/", (req, res) => {
  const { stationId, battery } = req.query;

  const station = stations.find(s => s.id == stationId);
  if (!station) return res.status(404).json({ error: "Station not found" });

  const chargerSpeed = station.kw;
  const needed = 100 - battery;
  const chargeTime = Math.round((needed / chargerSpeed) * 60);

  let waitTime = Math.floor(Math.random() * 20 + 5);
  const demand = waitTime > 15 ? "High" : "Low";

  res.json({
    station: station.name,
    charger: station.kw >= 50 ? "Fast" : "Regular",
    chargeTime,
    waitTime,
    demand
  });
});

module.exports = router;
