const express = require("express");
const router = express.Router();
const stations = require("../db/stations.json");

function toRad(value) {
  return (value * Math.PI) / 180;
}

function getDistance(lat1, lon1, lat2, lon2) {
  const R = 6371;
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);

  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(lat1)) *
      Math.cos(toRad(lat2)) *
      Math.sin(dLon / 2) ** 2;

  return (R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))).toFixed(2);
}

router.get("/", (req, res) => {
  const { lat, lng } = req.query;
  if (!lat || !lng) {
    return res.status(400).json({ error: "Latitude and Longitude required" });
  }

  const userLat = parseFloat(lat);
  const userLng = parseFloat(lng);

  const updated = stations.map(s => ({
    ...s,
    charger: s.kw >= 50 ? "Fast" : "Regular",
    distance: getDistance(userLat, userLng, s.lat, s.lng)
  }));

  updated.sort((a, b) => a.distance - b.distance);
  res.json(updated);
});

module.exports = router;
