const express = require("express");
const router = express.Router();
const fs = require("fs");
const path = require("path");

const BOOKINGS_FILE = path.join(__dirname, "../db/bookings.json");

router.post("/", (req, res) => {
  console.log("Incoming body:", req.body);

  const { station, vehicle, date, time, duration } = req.body;

  if (!station || !vehicle || !date || !time || !duration) {
    return res.status(400).json({ error: "Missing booking data" });
  }

  let bookings = [];
  if (fs.existsSync(BOOKINGS_FILE)) {
    bookings = JSON.parse(fs.readFileSync(BOOKINGS_FILE));
  }

  const newBooking = {
    id: Date.now(),
    station,
    vehicle,
    date,
    time,
    duration
  };

  bookings.push(newBooking);
  fs.writeFileSync(BOOKINGS_FILE, JSON.stringify(bookings, null, 2));

  res.json({ message: "Booking saved", booking: newBooking });
});

router.get("/", (req, res) => {
  const data = JSON.parse(fs.readFileSync(BOOKINGS_FILE));
  res.json(data);
});

module.exports = router;
