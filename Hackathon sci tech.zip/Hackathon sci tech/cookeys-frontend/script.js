window.addEventListener("load", () => {
  document.querySelectorAll("form").forEach(form => {
    form.addEventListener("submit", e => {
      e.preventDefault();
      console.log("Form submit blocked");
    });
  });
});

const API_BASE = "http://localhost:5000/api";

/***********************
 GLOBAL STATE
***********************/
let selectedVehicleType = "";
let selectedEV = "";
let selectedStation = "";
let selectedStationData = null;
let predictedChargeTime = 0;
let predictedWaitTime = 0;
let userLocation = { lat: null, lng: null };
let currentStations = [];



/***********************
 BASIC NAVIGATION
***********************/
function scrollToVehicle() {
  document.getElementById("vehicle-section")
    .scrollIntoView({ behavior: "smooth" });
}

function watchDemo() {
  document.getElementById("demo")
    .scrollIntoView({ behavior: "smooth" });
}

/***********************
 VEHICLE TYPE
***********************/
function selectVehicleType(type) {
  selectedVehicleType = type;

  twoWheelerCard.classList.remove("selected");
  fourWheelerCard.classList.remove("selected");

  if (type === "2-wheeler") twoWheelerCard.classList.add("selected");
  else fourWheelerCard.classList.add("selected");

  selectedVehicleTypeText.innerText = `Selected Vehicle: ${type}`;
  loadEVBrands();
}

/***********************
 EV MODAL
***********************/
function openEVModal() {
  if (!selectedVehicleType) {
    alert("Select vehicle type first");
    return;
  }
  evModal.style.display = "flex";
}

function closeEVModal() {
  evModal.style.display = "none";
}

async function loadEVBrands() {
  const res = await fetch(`${API_BASE}/evmodels/${selectedVehicleType}`);
  const data = await res.json();

  evBrand.innerHTML = `<option value="">Select Brand</option>`;
  Object.keys(data).forEach(b => {
    evBrand.innerHTML += `<option value="${b}">${b}</option>`;
  });
}

async function loadModels() {
  const brand = evBrand.value;
  const res = await fetch(`${API_BASE}/evmodels/${selectedVehicleType}`);
  const data = await res.json();

  evModel.innerHTML = `<option value="">Select Model</option>`;
  (data[brand] || []).forEach(m => {
    evModel.innerHTML += `<option>${m}</option>`;
  });
}

function saveEV() {
  selectedEV = `${evBrand.value} ${evModel.value}`;
  selectedEVText.innerText = `Selected EV: ${selectedEV}`;
  evSelect.innerHTML = `<option>${selectedEV}</option>`;
  closeEVModal();
}

/***********************
 CITY & AREA
***********************/
window.onload = () => {
  Object.keys(cityAreaData).forEach(c => {
    citySelect.innerHTML += `<option value="${c}">${cityAreaData[c].name}</option>`;
  });
};

function loadAreas() {
  const city = citySelect.value;
  areaSelect.innerHTML = `<option value="">Select Area</option>`;

  if (!city) return;

  Object.keys(cityAreaData[city].areas).forEach(a => {
    areaSelect.innerHTML += `<option value="${a}">${a}</option>`;
  });
}

/***********************
 GPS
***********************/
function useGPS() {
  navigator.geolocation.getCurrentPosition(pos => {
    userLocation.lat = pos.coords.latitude;
    userLocation.lng = pos.coords.longitude;
    locationStatus.style.display = "block";
    locationStatus.innerText = "Location detected successfully";
  });
}

/***********************
 FIND STATIONS
***********************/
async function findStations() {
  const city = citySelect.value;
  const area = areaSelect.value;
  const coords = cityAreaData[city].areas[area];

  const res = await fetch(
    `${API_BASE}/stations?lat=${coords.lat}&lng=${coords.lng}`
  );

  currentStations = await res.json();
  stationsGrid.innerHTML = "";

  currentStations.forEach(st => {
    stationsGrid.innerHTML += `
      <div class="station-card">
        <div class="station-body">
          <h3>${st.name}</h3>
          <p>${st.city}</p>
          <span>${st.distance} km</span>
          <p>${st.charger} Charger</p>
          <button onclick='selectStation(${JSON.stringify(st)})'>
            Select Station
          </button>
        </div>
      </div>`;
  });

  stations.classList.remove("hidden");
}

/***********************
 SELECT STATION
***********************/
function selectStation(st) {
  selectedStation = st.name;
  predictedChargeTime = st.chargeTime;
  predictedWaitTime = st.waitTime;
  selectedStationData = st;

  stationSelect.innerHTML = `<option>${st.name}</option>`;
  chargeTimePill.innerText = `${st.chargeTime} min`;
  waitTimePill.innerText = `${st.waitTime} min`;

  booking.scrollIntoView({ behavior: "smooth" });
}

/***********************
 CITY AND AREA DATA WITH COORDINATES
***********************/
const cityAreaData = {
 chennai: {
 name: "Chennai",
 lat: 13.0827,
 lng: 80.2707,
 areas: {
 "OMR": { lat: 12.9165, lng: 80.2270 },
 "Adyar": { lat: 13.0012, lng: 80.2565 },
 "T Nagar": { lat: 13.0418, lng: 80.2341 },
 "Velachery": { lat: 12.9815, lng: 80.2180 },
 "Anna Nagar": { lat: 13.0850, lng: 80.2101 },
 "Guindy": { lat: 13.0067, lng: 80.2206 },
 "Tambaram": { lat: 12.9249, lng: 80.1000 },
 "Porur": { lat: 13.0382, lng: 80.1582 },
 "Perungudi": { lat: 12.9653, lng: 80.2461 },
 "Nungambakkam": { lat: 13.0569, lng: 80.2425 },
 "Mylapore": { lat: 13.0368, lng: 80.2676 },
 "Besant Nagar": { lat: 13.0002, lng: 80.2668 },
 "Thiruvanmiyur": { lat: 12.9830, lng: 80.2594 },
 "Sholinganallur": { lat: 12.9010, lng: 80.2279 },
 "Chromepet": { lat: 12.9516, lng: 80.1462 },
 "Pallavaram": { lat: 12.9675, lng: 80.1491 },
 "Egmore": { lat: 13.0732, lng: 80.2609 },
 "Kodambakkam": { lat: 13.0529, lng: 80.2254 },
 "Vadapalani": { lat: 13.0520, lng: 80.2122 },
 "Ashok Nagar": { lat: 13.0374, lng: 80.2122 }
 }
 },
 mumbai: {
 name: "Mumbai",
 lat: 19.0760,
 lng: 72.8777,
 areas: {
 "Andheri": { lat: 19.1136, lng: 72.8697 },
 "Bandra": { lat: 19.0596, lng: 72.8295 },
 "Powai": { lat: 19.1176, lng: 72.9060 },
 "Lower Parel": { lat: 18.9985, lng: 72.8307 },
 "Thane": { lat: 19.2183, lng: 72.9781 },
 "Borivali": { lat: 19.2307, lng: 72.8567 },
 "Goregaon": { lat: 19.1663, lng: 72.8526 },
 "Kurla": { lat: 19.0726, lng: 72.8845 },
 "Navi Mumbai": { lat: 19.0330, lng: 73.0297 },
 "Worli": { lat: 19.0176, lng: 72.8156 },
 "Colaba": { lat: 18.9067, lng: 72.8147 },
 "Juhu": { lat: 19.1075, lng: 72.8263 },
 "Malad": { lat: 19.1874, lng: 72.8484 },
 "Kandivali": { lat: 19.2047, lng: 72.8547 },
 "Dadar": { lat: 19.0176, lng: 72.8427 },
 "Chembur": { lat: 19.0522, lng: 72.8994 },
 "Vashi": { lat: 19.0771, lng: 72.9987 },
 "Mulund": { lat: 19.1726, lng: 72.9569 },
 "Vikhroli": { lat: 19.1096, lng: 72.9279 },
 "Santacruz": { lat: 19.0813, lng: 72.8410 }
 }
 },
 pune: {
 name: "Pune",
 lat: 18.5204,
 lng: 73.8567,
 areas: {
 "Hinjewadi": { lat: 18.5912, lng: 73.7380 },
 "Baner": { lat: 18.5590, lng: 73.7868 },
 "Viman Nagar": { lat: 18.5679, lng: 73.9143 },
 "Wakad": { lat: 18.5980, lng: 73.7610 },
 "Kothrud": { lat: 18.5074, lng: 73.8077 },
 "Hadapsar": { lat: 18.5089, lng: 73.9260 },
 "Aundh": { lat: 18.5580, lng: 73.8073 },
 "Kharadi": { lat: 18.5511, lng: 73.9406 },
 "Pimpri": { lat: 18.6279, lng: 73.8009 },
 "Chinchwad": { lat: 18.6298, lng: 73.7997 },
 "Magarpatta": { lat: 18.5146, lng: 73.9278 },
 "Koregaon Park": { lat: 18.5362, lng: 73.8936 },
 "Shivaji Nagar": { lat: 18.5314, lng: 73.8446 },
 "Camp": { lat: 18.5127, lng: 73.8800 },
 "Deccan": { lat: 18.5167, lng: 73.8411 },
 "Bibwewadi": { lat: 18.4764, lng: 73.8593 },
 "Warje": { lat: 18.4818, lng: 73.8015 },
 "Bavdhan": { lat: 18.5121, lng: 73.7712 },
 "Pashan": { lat: 18.5361, lng: 73.7853 },
 "Kalyani Nagar": { lat: 18.5463, lng: 73.9019 }
 }
 },
 bangalore: {
 name: "Bangalore",
 lat: 12.9716,
 lng: 77.5946,
 areas: {
 "Whitefield": { lat: 12.9698, lng: 77.7500 },
 "Electronic City": { lat: 12.8399, lng: 77.6770 },
 "Koramangala": { lat: 12.9352, lng: 77.6245 },
 "Indiranagar": { lat: 12.9784, lng: 77.6408 },
 "HSR Layout": { lat: 12.9116, lng: 77.6389 },
 "JP Nagar": { lat: 12.9063, lng: 77.5857 },
 "Marathahalli": { lat: 12.9591, lng: 77.6974 },
 "Bellandur": { lat: 12.9260, lng: 77.6762 },
 "Sarjapur": { lat: 12.8610, lng: 77.7865 },
 "Hebbal": { lat: 13.0358, lng: 77.5970 },
 "Yelahanka": { lat: 13.1007, lng: 77.5963 },
 "Jayanagar": { lat: 12.9308, lng: 77.5838 },
 "Banashankari": { lat: 12.9255, lng: 77.5468 },
 "BTM Layout": { lat: 12.9166, lng: 77.6101 },
 "MG Road": { lat: 12.9758, lng: 77.6045 },
 "Brigade Road": { lat: 12.9716, lng: 77.6096 },
 "Malleshwaram": { lat: 13.0035, lng: 77.5647 },
 "Rajajinagar": { lat: 12.9864, lng: 77.5525 },
 "Basavanagudi": { lat: 12.9425, lng: 77.5746 },
 "Bannerghatta": { lat: 12.8002, lng: 77.5773 }
 }
 },
 delhi: {
 name: "Delhi",
 lat: 28.7041,
 lng: 77.1025,
 areas: {
 "Connaught Place": { lat: 28.6315, lng: 77.2167 },
 "Karol Bagh": { lat: 28.6528, lng: 77.1900 },
 "Dwarka": { lat: 28.5921, lng: 77.0460 },
 "Rohini": { lat: 28.7495, lng: 77.0565 },
 "Lajpat Nagar": { lat: 28.5677, lng: 77.2433 },
 "Saket": { lat: 28.5244, lng: 77.2167 },
 "Vasant Kunj": { lat: 28.5195, lng: 77.1564 },
 "Greater Kailash": { lat: 28.5365, lng: 77.2433 },
 "Nehru Place": { lat: 28.5491, lng: 77.2533 },
 "Hauz Khas": { lat: 28.5494, lng: 77.2001 },
 "Defence Colony": { lat: 28.5743, lng: 77.2300 },
 "Green Park": { lat: 28.5601, lng: 77.2067 },
 "South Extension": { lat: 28.5677, lng: 77.2267 },
 "Rajouri Garden": { lat: 28.6467, lng: 77.1233 },
 "Janakpuri": { lat: 28.6289, lng: 77.0817 },
 "Pitampura": { lat: 28.6989, lng: 77.1333 },
 "Preet Vihar": { lat: 28.6421, lng: 77.2967 },
 "Mayur Vihar": { lat: 28.6089, lng: 77.2967 },
 "Noida": { lat: 28.5355, lng: 77.3910 },
 "Gurgaon": { lat: 28.4595, lng: 77.0266 }
 }
 },
 hyderabad: {
 name: "Hyderabad",
 lat: 17.3850,
 lng: 78.4867,
 areas: {
 "HITEC City": { lat: 17.4435, lng: 78.3772 },
 "Gachibowli": { lat: 17.4401, lng: 78.3489 },
 "Banjara Hills": { lat: 17.4156, lng: 78.4347 },
 "Jubilee Hills": { lat: 17.4326, lng: 78.4071 },
 "Madhapur": { lat: 17.4483, lng: 78.3915 },
 "Kondapur": { lat: 17.4576, lng: 78.3578 },
 "Kukatpally": { lat: 17.4849, lng: 78.3883 },
 "Begumpet": { lat: 17.4416, lng: 78.4633 },
 "Secunderabad": { lat: 17.4399, lng: 78.4983 },
 "Ameerpet": { lat: 17.4375, lng: 78.4483 },
 "Somajiguda": { lat: 17.4277, lng: 78.4520 },
 "Miyapur": { lat: 17.4969, lng: 78.3537 },
 "Manikonda": { lat: 17.4022, lng: 78.3870 },
 "Financial District": { lat: 17.4220, lng: 78.3420 },
 "Uppal": { lat: 17.4013, lng: 78.5594 },
 "LB Nagar": { lat: 17.3482, lng: 78.5515 },
 "Dilsukhnagar": { lat: 17.3688, lng: 78.5247 },
 "Himayatnagar": { lat: 17.4012, lng: 78.4850 },
 "Abids": { lat: 17.3936, lng: 78.4746 },
 "Shamshabad": { lat: 17.2403, lng: 78.4294 }
 }
 },
 kolkata: {
 name: "Kolkata",
 lat: 22.5726,
 lng: 88.3639,
 areas: {
 "Salt Lake": { lat: 22.5958, lng: 88.4097 },
 "Park Street": { lat: 22.5515, lng: 88.3512 },
 "New Town": { lat: 22.5958, lng: 88.4848 },
 "Howrah": { lat: 22.5958, lng: 88.2636 },
 "Ballygunge": { lat: 22.5266, lng: 88.3633 },
 "Alipore": { lat: 22.5344, lng: 88.3389 },
 "Behala": { lat: 22.4981, lng: 88.3100 },
 "Jadavpur": { lat: 22.4966, lng: 88.3716 },
 "Dum Dum": { lat: 22.6234, lng: 88.4233 },
 "Tollygunge": { lat: 22.4981, lng: 88.3533 },
 "Gariahat": { lat: 22.5184, lng: 88.3686 },
 "Kasba": { lat: 22.5184, lng: 88.3897 },
 "Bhowanipore": { lat: 22.5266, lng: 88.3400 },
 "Esplanade": { lat: 22.5633, lng: 88.3500 },
 "Sealdah": { lat: 22.5697, lng: 88.3697 },
 "Lake Town": { lat: 22.5958, lng: 88.3900 },
 "Kankurgachi": { lat: 22.5797, lng: 88.3900 },
 "Ultadanga": { lat: 22.5897, lng: 88.3830 },
 "Shyambazar": { lat: 22.5958, lng: 88.3700 },
 "Barasat": { lat: 22.7234, lng: 88.4797 }
 }
 },
 ahmedabad: {
 name: "Ahmedabad",
 lat: 23.0225,
 lng: 72.5714,
 areas: {
 "SG Highway": { lat: 23.0469, lng: 72.5170 },
 "Prahlad Nagar": { lat: 23.0120, lng: 72.5120 },
 "Satellite": { lat: 23.0120, lng: 72.5020 },
 "Navrangpura": { lat: 23.0369, lng: 72.5570 },
 "CG Road": { lat: 23.0320, lng: 72.5570 },
 "Vastrapur": { lat: 23.0320, lng: 72.5270 },
 "Bodakdev": { lat: 23.0420, lng: 72.5070 },
 "Thaltej": { lat: 23.0520, lng: 72.5070 },
 "Maninagar": { lat: 22.9920, lng: 72.6070 },
 "Gota": { lat: 23.0869, lng: 72.5470 },
 "Chandkheda": { lat: 23.1069, lng: 72.5870 },
 "Bopal": { lat: 22.9869, lng: 72.4670 },
 "South Bopal": { lat: 22.9769, lng: 72.4570 },
 "Ambawadi": { lat: 23.0220, lng: 72.5520 },
 "Paldi": { lat: 23.0120, lng: 72.5620 },
 "Ellis Bridge": { lat: 23.0269, lng: 72.5620 },
 "Law Garden": { lat: 23.0269, lng: 72.5520 },
 "Ashram Road": { lat: 23.0369, lng: 72.5720 },
 "Sabarmati": { lat: 23.0669, lng: 72.5820 },
 "Gandhinagar": { lat: 23.2156, lng: 72.6369 }
 }
 },
 jaipur: {
 name: "Jaipur",
 lat: 26.9124,
 lng: 75.7873,
 areas: {
 "Malviya Nagar": { lat: 26.8520, lng: 75.8170 },
 "Vaishali Nagar": { lat: 26.9120, lng: 75.7270 },
 "C Scheme": { lat: 26.9120, lng: 75.7870 },
 "MI Road": { lat: 26.9220, lng: 75.7920 },
 "Mansarovar": { lat: 26.8770, lng: 75.7570 },
 "Raja Park": { lat: 26.9070, lng: 75.8170 },
 "Tonk Road": { lat: 26.8670, lng: 75.7970 },
 "Ajmer Road": { lat: 26.8920, lng: 75.7270 },
 "JLN Marg": { lat: 26.8870, lng: 75.8070 },
 "Bani Park": { lat: 26.9320, lng: 75.7820 },
 "Sodala": { lat: 26.9020, lng: 75.7570 },
 "Nirman Nagar": { lat: 26.8870, lng: 75.7470 },
 "Jhotwara": { lat: 26.9370, lng: 75.7470 },
 "Durgapura": { lat: 26.8520, lng: 75.7670 },
 "Jagatpura": { lat: 26.8220, lng: 75.8470 },
 "Sitapura": { lat: 26.7920, lng: 75.8470 },
 "Sanganer": { lat: 26.8270, lng: 75.7970 },
 "Gopalpura": { lat: 26.8420, lng: 75.7870 },
 "Lalkothi": { lat: 26.8970, lng: 75.7970 },
 "Bapu Nagar": { lat: 26.9070, lng: 75.7820 }
 }
 },
 lucknow: {
 name: "Lucknow",
 lat: 26.8467,
 lng: 80.9462,
 areas: {
 "Gomti Nagar": { lat: 26.8570, lng: 81.0170 },
 "Hazratganj": { lat: 26.8520, lng: 80.9470 },
 "Aliganj": { lat: 26.8920, lng: 80.9420 },
 "Indira Nagar": { lat: 26.8770, lng: 80.9920 },
 "Mahanagar": { lat: 26.8770, lng: 80.9520 },
 "Vikas Nagar": { lat: 26.8670, lng: 80.9820 },
 "Alambagh": { lat: 26.8170, lng: 80.9120 },
 "Aashiana": { lat: 26.7970, lng: 80.9420 },
 "Jankipuram": { lat: 26.9170, lng: 80.9970 },
 "Rajajipuram": { lat: 26.8670, lng: 80.8920 },
 "Aminabad": { lat: 26.8520, lng: 80.9220 },
 "Charbagh": { lat: 26.8320, lng: 80.9220 },
 "Cantt": { lat: 26.8420, lng: 80.9070 },
 "Sushant Golf City": { lat: 26.7870, lng: 81.0320 },
 "Chinhat": { lat: 26.8870, lng: 81.0470 },
 "Triveni Nagar": { lat: 26.8670, lng: 80.8670 },
 "Daliganj": { lat: 26.8920, lng: 80.9320 },
 "Krishna Nagar": { lat: 26.8420, lng: 80.9620 },
 "Khurram Nagar": { lat: 26.8970, lng: 80.9620 },
 "Sarojini Nagar": { lat: 26.8120, lng: 80.8920 }
 }
 }
};
/***********************
 STATION TEMPLATES - 9 PER AREA
***********************/
const stationTemplates = [
 { suffix: "EV Hub", power: 150, connectors: 8, chargerType: "fast" },
 { suffix: "EV Station", power: 120, connectors: 6, chargerType: "fast" },
 { suffix: "EV Point", power: 50, connectors: 4, chargerType: "regular" },
 { suffix: "EV Plaza", power: 180, connectors: 10, chargerType: "fast" },
 { suffix: "EV Center", power: 45, connectors: 3, chargerType: "regular" },
 { suffix: "Charging Hub", power: 140, connectors: 7, chargerType: "fast" },
 { suffix: "Quick Charge", power: 160, connectors: 8, chargerType: "fast" },
 { suffix: "EV Stop", power: 40, connectors: 3, chargerType: "regular" },
 { suffix: "Power Station", power: 100, connectors: 5, chargerType: "regular" }
];
/***********************
 EV MODELS BY VEHICLE TYPE
***********************/
const evModels = {
 "2-wheeler": {
 "Ather": ["450X", "450 Plus", "450S"],
 "Ola": ["S1 Pro", "S1 Air", "S1 X"],
 "TVS": ["iQube", "iQube ST", "iQube S"],
 "Bajaj": ["Chetak", "Chetak Premium"],
 "Hero": ["Vida V1", "Vida V1 Pro", "Vida V1 Plus"],
 "Ampere": ["Nexus", "Primus", "Magnus EX"]
 },
 "4-wheeler": {
 "Tata": ["Nexon EV", "Tiago EV", "Tigor EV", "Punch EV", "Nexon EV Max"],
 "Mahindra": ["XUV400", "eVerito", "XUV400 EL"],
 "MG": ["ZS EV", "Comet EV", "ZS EV Exclusive"],
 "Hyundai": ["Kona Electric", "Ioniq 5", "Ioniq 6"],
 "BYD": ["Atto 3", "e6", "Seal"],
 "Kia": ["EV6", "EV6 GT"]
 }
};
/***********************
 GENERATE STATIONS FOR AREA
***********************/
function generateStationsForArea(city, area) {
 const cityData = cityAreaData[city];
 const areaCoords = cityData.areas[area];

 return stationTemplates.map((template, index) => {
 const latOffset = (Math.random() - 0.5) * 0.02;
 const lngOffset = (Math.random() - 0.5) * 0.02;

 return {
 name: `${area} ${template.suffix}`,
 power: template.power,
 connectors: template.connectors,
 chargerType: template.chargerType,
 imageIndex: index + 1,
 lat: areaCoords.lat + latOffset,
 lng: areaCoords.lng + lngOffset
 };
 });
}
/***********************
 GENERATE CONNECTOR STATUS
***********************/
function generateConnectorStatus(totalConnectors) {
 const rand = Math.random();
 let status, occupied, free;

 if (rand < 0.08) {
 status = "unknown";
 occupied = 0;
 free = 0;
 } else if (rand < 0.25) {
 status = "occupied";
 occupied = totalConnectors;
 free = 0;
 } else {
 free = Math.floor(Math.random() * totalConnectors) + 1;
 occupied = totalConnectors - free;
 status = "available";
 }

 return { status, occupied, free, total: totalConnectors };
}
/***********************
 CALCULATE DISTANCE (Haversine Formula)
***********************/
function calculateDistance(lat1, lng1, lat2, lng2) {
 const R = 6371; // Earth's radius in km
 const dLat = (lat2 - lat1) * Math.PI / 180;
 const dLng = (lng2 - lng1) * Math.PI / 180;
 const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
 Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
 Math.sin(dLng/2) * Math.sin(dLng/2);
 const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
 return R * c;
}
/***********************
 BUILD STATIONS DATA
***********************/
function buildStationsData(city, area) {
 const stationTemplatesData = generateStationsForArea(city, area);

 const stations = stationTemplatesData.map((station, index) => {
 const connectorInfo = generateConnectorStatus(station.connectors);
 const chargeTime = station.chargerType === 'fast'
 ? Math.round((75 / station.power) * 60 * 0.8)
 : Math.round((75 / station.power) * 60);
 const waitTime = connectorInfo.status === "available"
 ? Math.round(3 + Math.random() * 12)
 : Math.round(15 + Math.random() * 25);

 let distance = null;
 if (userLocation.lat && userLocation.lng) {
 distance = calculateDistance(userLocation.lat, userLocation.lng, station.lat,
station.lng);
 } else {
 distance = 0.5 + Math.random() * 5;
 }

 return {
 ...station,
 ...connectorInfo,
 chargeTime,
 waitTime,
 distance: distance.toFixed(1),
 image: `images/station${station.imageIndex}.jpg`,
 city: city,
 area: area
 };
 });
 // Sort by availability first, then by free connectors, then by distance
 stations.sort((a, b) => {
 if (a.status === "available" && b.status !== "available") return -1;
 if (a.status !== "available" && b.status === "available") return 1;
 if (b.free !== a.free) return b.free - a.free;
 return parseFloat(a.distance) - parseFloat(b.distance);
 });
 return stations;
}
/***********************
 INITIALIZE CITY DROPDOWN
***********************/
function initializeCityDropdown() {
 const citySelect = document.getElementById("citySelect");
 citySelect.innerHTML = '<option value="">Select City</option>';

 Object.keys(cityAreaData).forEach(cityKey => {
 const option = document.createElement("option");
 option.value = cityKey;
 option.textContent = cityAreaData[cityKey].name;
 citySelect.appendChild(option);
 });
}
/***********************
 LOAD AREAS
***********************/
function loadAreas() {
 const city = document.getElementById("citySelect").value;
 const areaSelect = document.getElementById("areaSelect");
 areaSelect.innerHTML = '<option value="">Select Area</option>';

 if (city && cityAreaData[city]) {
 Object.keys(cityAreaData[city].areas).forEach(area => {
 const option = document.createElement("option");
 option.value = area;
 option.textContent = area;
 areaSelect.appendChild(option);
 });
 }
}
/***********************
 VEHICLE TYPE SELECTION
***********************/
function selectVehicleType(type) {
 selectedVehicleType = type;

 document.getElementById("twoWheelerCard").classList.remove("selected");
 document.getElementById("fourWheelerCard").classList.remove("selected");

 if (type === "2-wheeler") {
 document.getElementById("twoWheelerCard").classList.add("selected");
 } else {
 document.getElementById("fourWheelerCard").classList.add("selected");
 }

 document.getElementById("selectedVehicleType").textContent = `Selected: ${type
=== "2-wheeler" ? "2-Wheeler (Scooter/Bike)" : "4-Wheeler (Car/SUV)"}`;

 // Reset EV selection
 selectedEV = "";
 document.getElementById("selectedEV").textContent = "";
 document.getElementById("evSelect").innerHTML = '<option value="">Select your EV first</option>';



 // Update brand dropdown
 updateBrandDropdown();
}
function updateBrandDropdown() {
 const brandSelect = document.getElementById("evBrand");
 brandSelect.innerHTML = '<option value="">Select Brand</option>';

 if (selectedVehicleType && evModels[selectedVehicleType]) {
 Object.keys(evModels[selectedVehicleType]).forEach(brand => {
 const option = document.createElement("option");
 option.value = brand;
 option.textContent = brand;
 brandSelect.appendChild(option);
 });
 }

 document.getElementById("evModel").innerHTML = '<option value="">Select Model</option>';

}
/***********************
 EV MODAL
***********************/
function openEVModal() {
 if (!selectedVehicleType) {
 alert("Please select vehicle type first (2-Wheeler or 4-Wheeler)");
 return;
 }
 document.getElementById("evModal").style.display = "flex";
}
function closeEVModal() {
 document.getElementById("evModal").style.display = "none";
}
function loadModels() {
 const brand = document.getElementById("evBrand").value;
 const modelSelect = document.getElementById("evModel");
 modelSelect.innerHTML = '<option value="">Select Model</option>';

 if (selectedVehicleType && evModels[selectedVehicleType] &&
evModels[selectedVehicleType][brand]) {
 evModels[selectedVehicleType][brand].forEach(model => {
 modelSelect.add(new Option(model, model));
 });
 }
}
function saveEV() {
 const brand = document.getElementById("evBrand").value;
 const model = document.getElementById("evModel").value;

 if (!brand) {
 alert("Please select brand");
 return;
 }
 if (!model) {
 alert("Please select model");
 return;
 }

 selectedEV = `${brand} ${model}`;
 document.getElementById("selectedEV").textContent = `Selected: ${selectedEV}`;
 document.getElementById("evSelect").innerHTML = `<option>${selectedEV}</option>`;
 closeEVModal();
}
/***********************
 USE GPS
***********************/
function useGPS() {
 const statusDiv = document.getElementById("locationStatus");
 statusDiv.style.display = "block";
 statusDiv.textContent = "Detecting your location...";
 statusDiv.style.background = "linear-gradient(135deg, rgba(255, 200, 0, 0.15), rgba(255, 150, 0, 0.25))";


 statusDiv.style.color = "#92400e";
 if (!navigator.geolocation) {
 statusDiv.textContent = "Geolocation is not supported by your browser";
 statusDiv.style.background = "linear-gradient(135deg, rgba(220,38,38,0.15), rgba(185,28,28,0.15))";
 statusDiv.style.color = "#991b1b";
 return;
 }
 navigator.geolocation.getCurrentPosition(
 (position) => {
 userLocation.lat = position.coords.latitude;
 userLocation.lng = position.coords.longitude;

 // Find nearest city
 let nearestCity = null;
 let minDistance = Infinity;

 Object.keys(cityAreaData).forEach(cityKey => {
 const city = cityAreaData[cityKey];
 const distance = calculateDistance(userLocation.lat, userLocation.lng,
city.lat, city.lng);
 if (distance < minDistance) {
 minDistance = distance;
 nearestCity = cityKey;
 }
 });
 if (nearestCity) {
 document.getElementById("citySelect").value = nearestCity;
 loadAreas();

 // Find nearest area
 const areas = cityAreaData[nearestCity].areas;
 let nearestArea = Object.keys(areas)[0];
 let minAreaDistance = Infinity;

 Object.keys(areas).forEach(areaName => {
 const areaCoords = areas[areaName];
 const distance = calculateDistance(userLocation.lat, userLocation.lng,
areaCoords.lat, areaCoords.lng);
 if (distance < minAreaDistance) {
 minAreaDistance = distance;
 nearestArea = areaName;
 }
 });

 setTimeout(() => {
 document.getElementById("areaSelect").value = nearestArea;
 }, 100);
 statusDiv.textContent = `Location detected:
${cityAreaData[nearestCity].name} - ${nearestArea} (${minAreaDistance.toFixed(1)}
km away)`;
 statusDiv.style.background = "linear-gradient(135deg, rgba(0, 198, 255, 0.1), rgba(0, 255, 163, 0.1))";
 statusDiv.style.color = "var(--info)";
 setTimeout(() => {
 findStations();
 }, 800);
 }
 },
 (error) => {
 statusDiv.textContent = "Unable to retrieve your location. Please select manually.";
 statusDiv.style.background = "linear-gradient(135deg, rgba(220, 38, 38, 0.15), rgba(185, 28, 28, 0.15))";
 statusDiv.style.color = "#991b1b";
 },
 {
 enableHighAccuracy: true,
 timeout: 10000,
 maximumAge: 0
 }
 );
}
/***********************
 FIND STATIONS
***********************/
function findStations() {
 const city = document.getElementById("citySelect").value;
 const areaSelect = document.getElementById("areaSelect");
 const areaValue = areaSelect.value;
 const section = document.getElementById("stations");

 if (!city) {
 alert("Please select a city");
 return;
 }
 if (!areaValue) {
 alert("Please select an area");
 return;
 }
 selectedCity = city;
 selectedArea = areaValue;
 renderStations();
 section.classList.remove("hidden");
 section.scrollIntoView({ behavior: "smooth" });
}
/***********************
 RENDER STATIONS
***********************/
function renderStations() {
 const grid = document.getElementById("stationsGrid");
 currentStations = buildStationsData(selectedCity, selectedArea);

 grid.innerHTML = currentStations.map((station, index) => `
 <div class="station-card" data-index="${index}">
 <img src="${station.image}" alt="${station.name}"
onerror="this.src='https://images.unsplash.com/photo-1593941707882-a5bba14938c7?w=4
00&h=200&fit=crop'">
 <div class="station-body">
 <div class="station-header">
 <h3>${station.name}</h3>
 <span class="distance-badge">${station.distance} km</span>
 </div>
 <p class="station-city">${selectedArea},
${cityAreaData[selectedCity].name}</p>

 <div class="badges-row">
 <span class="power-badge">${station.power} kW</span>
 <span class="charger-type-badge
${station.chargerType}">${station.chargerType === 'fast' ? 'Fast Charger' :
'Regular'}</span>
 <span class="status-badge
${station.status}">${getStatusLabel(station.status)}</span>
 </div>

 <div class="connector-info">
 <h4>Connector Status</h4>
 <div class="connector-row">
 <span class="connector-label">Total</span>
 <span class="connector-value total">${station.total}</span>
 </div>
 <div class="connector-row">
 <span class="connector-label">Occupied</span>
 <span class="connector-value occupied">${station.status === 'unknown' ?
'-' : station.occupied}</span>
 </div>
 <div class="connector-row">
 <span class="connector-label">Available</span>
 <span class="connector-value free">${station.status === 'unknown' ? '-'
: station.free}</span>
 </div>
 </div>

 <div class="prediction-box">
 <div class="prediction-item">
 <span>Charge Time</span>
 <strong>${station.chargeTime} min</strong>
 </div>
 <div class="prediction-item">
 <span>Wait Time</span>
 <strong>${station.waitTime} min</strong>
 </div>
 </div>

 <button class="select-btn" onclick="selectStation(${index})">Select
Station</button>
 <button class="direction-btn" onclick="getDirections(${index})">Get
Directions - ${station.distance} km</button>
 </div>
 </div>
 `).join('');
}
/***********************
 GET STATUS LABEL
***********************/
function getStatusLabel(status) {
 switch(status) {
 case 'available': return 'Available';
 case 'occupied': return 'Occupied';
 case 'unknown': return 'Unknown';
 default: return status;
 }
}
/***********************
 GET DIRECTIONS (Fixed Google Maps)
***********************/
function getDirections(index) {
 const station = currentStations[index];
 const destLat = station.lat;
 const destLng = station.lng;

 let mapsUrl;

 if (userLocation.lat && userLocation.lng) {
 // Use directions with origin and destination
 mapsUrl =
`https://www.google.com/maps/dir/?api=1&origin=${userLocation.lat},${userLocation.lng}&destination=${destLat},${destLng}&travelmode=driving`;
 } else {
 // Just show the destination
 mapsUrl =
`https://www.google.com/maps/search/?api=1&query=${destLat},${destLng}`;
 }

 window.open(mapsUrl, '_blank');
}
/***********************
 SELECT STATION
***********************/
function selectStation(index) {
 const station = currentStations[index];

 selectedStation = station.name;
 selectedStationData = station;
 predictedChargeTime = station.chargeTime;
 predictedWaitTime = station.waitTime;
 document.getElementById("stationSelect").innerHTML =
`<option>${station.name}</option>`;
 document.getElementById("chargeTimePill").textContent = `${station.chargeTime}
min`;
 document.getElementById("waitTimePill").textContent = `${station.waitTime} min`;

 document.getElementById("detailConnectors").textContent = station.total;
 document.getElementById("detailPower").textContent = `${station.power} kW`;
 document.getElementById("detailChargerType").textContent = station.chargerType
=== 'fast' ? 'Fast Charger' : 'Regular';
 document.getElementById("detailStatus").textContent =
getStatusLabel(station.status);
 document.getElementById("detailFree").textContent = station.status === 'unknown'
? 'Unknown' : station.free;
 document.getElementById("detailDistance").textContent = `${station.distance} km`;
 document.getElementById("booking").scrollIntoView({ behavior: "smooth" });
}
/***********************
 BOOK SESSION
***********************/
function bookSession(event) {
  if (event) event.preventDefault();

  const date = document.getElementById("dateInput").value;
  const time = document.getElementById("timeInput").value;

  if (!selectedEV || !selectedStation || !date || !time) {
    alert("Please complete all fields");
    return;
  }

  fetch("http://localhost:5000/api/bookings", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      station: selectedStation,
      vehicle: selectedEV,
      date: date,
      time: time,
      duration: predictedChargeTime
    })
  })
  .then(res => res.json())
  .then(data => {
    console.log("Booking saved:", data);

    document.getElementById("cStation").textContent = selectedStation;
    document.getElementById("cVehicle").textContent = selectedEV;
    document.getElementById("cDate").textContent = `${date} at ${time}`;
    document.getElementById("cDuration").textContent = `${predictedChargeTime} minutes`;
    document.getElementById("cChargerType").textContent =
      selectedStationData?.chargerType === "fast" ? "Fast Charger" : "Regular Charger";

    document.getElementById("confirmModal").style.display = "flex";
  })
  .catch(err => console.error(err));
}

document.addEventListener("DOMContentLoaded", () => {
  const btn = document.getElementById("bookBtn");
  if (btn) {
    btn.addEventListener("click", e => {
      e.preventDefault();
      bookSession();
    });
  }
});




/***********************
 CONFIRM MODAL
***********************/
function closeConfirm() {
 document.getElementById("confirmModal").style.display = "none";
}
/***********************
 HELPERS
***********************/
function scrollToVehicle() {
 document.getElementById("vehicle-section").scrollIntoView({ behavior: "smooth"
});
}
function watchDemo() {
 document.getElementById("demo").scrollIntoView({ behavior: "smooth" });
}
/***********************
 INITIALIZE
***********************/
document.addEventListener('DOMContentLoaded', function() {
 initializeCityDropdown();

 const today = new Date().toISOString().split('T')[0];
 document.getElementById('dateInput').setAttribute('min', today);
 document.getElementById('dateInput').value = today;

 const now = new Date();
 const hours = String(now.getHours()).padStart(2, '0');
 const minutes = String(now.getMinutes()).padStart(2, '0');
 document.getElementById('timeInput').value = `${hours}:${minutes}`;
});
